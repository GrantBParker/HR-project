package edu.waketech.csc251.hr.mgmt;

import edu.waketech.csc251.tools.Screener;

public class ManagerScreener<T> implements Screener<T>{

	@Override
	public boolean test(T objToTest) {
		String simpleName = objToTest.getClass().getSimpleName();
		if(simpleName.equals("Manager")) {
			return true;
		}
		else return false;
	}

}
