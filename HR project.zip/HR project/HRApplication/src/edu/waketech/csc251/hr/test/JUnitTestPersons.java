package edu.waketech.csc251.hr.test;

import edu.waketech.csc251.hr.person.Employee;
import edu.waketech.csc251.hr.person.EmployeeScreener;
import edu.waketech.csc251.tools.Screener;
import edu.waketech.csc251.hr.mgmt.Manager;
import edu.waketech.csc251.hr.mgmt.ManagerScreener;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import edu.waketech.csc251.hr.mgmt.Executive;
import edu.waketech.csc251.hr.mgmt.ExecutiveScreen;

public class JUnitTestPersons {
	
	void test() {
		
		Employee emp = new Employee("John", 1000);
		Manager mgr = new Manager("John", 1000, "Sales");
		Executive exec = new Executive("John", 1000, "Production");
		
		Screener<Employee> screenerEmp = new EmployeeScreener<Employee>();
		Screener<Employee> screenerMgr = new ManagerScreener<Employee>();
		Screener<Employee> screenerExec = new ExecutiveScreen<Employee>();
		
		assertTrue(screenerEmp.test(emp));
		assertFalse(screenerMgr.test(emp));
		assertFalse(screenerExec.test(emp));
		
		assertFalse(screenerMgr.test(emp));
		assertTrue(screenerMgr.test(emp));
		assertFalse(screenerExec.test(emp));
		
		assertFalse(screenerEmp.test(emp));
		assertFalse(screenerMgr.test(emp));
		assertTrue(screenerExec.test(emp));
	}

}
