package edu.waketech.csc251.hr.person;

import edu.waketech.csc251.collection.Measurable;

public class Employee implements Measurable{
	private String name;
	private double salary;

	/**
	 *no arg superclass constructor
	 */
	public Employee () {
	}

	/**
	 * @param name
	 * @param salary
	 */
	public Employee(String name, double salary) {
		this.name = name;
		this.salary = salary;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the salary
	 */
	public double getSalary() {
		return salary;
	}

	/**
	 * @param salary the salary to set
	 */
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	/**
	 * @return the salary measurable
	 */
	@Override
	public int getMeasure() {
		// TODO Auto-generated method stub
		return (int) this.salary;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Employee [name=" + name + ", salary=" + salary + "]";
	}
	
}
