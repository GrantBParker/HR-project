package edu.waketech.csc251.hr.person;

import edu.waketech.csc251.tools.Screener;

//Does employee only not manager and executive
public class EmployeeScreener<T> implements Screener<T>{
	
	
	@Override
	//use static so is does not make an instance
	public boolean test(T objToTest) {
		String simpleName = objToTest.getClass().getSimpleName();
		if (simpleName.equals("Executive")){
			return true;
			
		}
		
		else {
			return false;
		}
		
	}

}
