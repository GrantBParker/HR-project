package edu.waketech.csc251.hr.mgmt;

public class Executive extends Manager {
	
	 double bonusRate;

	public Executive() {
		super();
	}

	public Executive(String name, double salary, String department) {
		this.setName(name);
		this.setDepartment(department);
		double incBonus = (salary + salary * bonusRate);
		this.setSalary(incBonus);
	}
	
	public Executive(String name, double salary, String department, double bonusRate) {
		this.setName(name);
		this.setDepartment(department);
		this.bonusRate = bonusRate;
		double incBonus = (salary + salary * bonusRate);
		this.setSalary(incBonus);
	}

	@Override
	public String toString() {
		return "Executive [name=" + this.getName() + ", salary with bonus=" + this.getSalary() + ", department=" + this.getDepartment()
				+  ", bonus rate =" + this.getBonusRate() + "]";
	}

	public double getBonusRate() {
		return bonusRate;
	}

	public void setBonusRate(double bonusRate) {
		this.bonusRate = bonusRate;
	}
	
}