package edu.waketech.csc251.hr.mgmt;

import edu.waketech.csc251.hr.person.Employee;

public class Manager extends Employee{
	
	private String department;

	public Manager() {
		super();
	}
	
	public Manager(String name, double salary, String department) {
		super();
		this.setName(name);
		this.setSalary(salary);
		this.department = department;		
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	@Override
	public String toString() {
		return "Manager [name=" + this.getName() + ", salary=" + this.getSalary() + ", department=" + this.getDepartment() + "]";
	}
	
}
