package edu.waketech.csc251.hr.mgmt;

import edu.waketech.csc251.tools.Screener;

//does executive only
public class ExecutiveScreen<T> implements Screener<T>{

	@Override
	public boolean test(T objToTest) {
		String simpleName = objToTest.getClass().getSimpleName();
		if(simpleName.equals("Exectuive")) {
			return true;
		}
		else return false;
	}

}