package edu.waketech.csc251.collection;

import java.util.*;

import edu.waketech.csc251.tools.Screener;

public class DataSetGeneric<T extends Measurable> extends ArrayList<T>{

	private ArrayList<T> data;

	public DataSetGeneric() {
		data = new ArrayList<>();
	}

	public boolean add(T objToAdd) {
		return data.add(objToAdd);
	}

	public int size() {
		return data.size();
	}

	public T getMax() {
		if (data.isEmpty()) {
			return null;
		}
		T mEle = data.get(0);
		for (int i = 1; i < data.size(); i++) {
			if ((mEle).getMeasure() < ((data.get(i)).getMeasure())) {
				mEle = data.get(i);
			}
		}
		return mEle;
	}
	

	
	public T getMin() {
		if (data.isEmpty()) {
			return null;
		}
		T mEle = data.get(0);
		for (int i = 1; i < data.size(); i++) {
			if ((mEle).getMeasure() > ((data.get(i)).getMeasure())) {
				mEle = data.get(i);
			}
		}
		return mEle;
	}

	public ArrayList<T> getList() {
		if(data.isEmpty()) {
		return null;
		}
		else {
			return data;
		}
		} 
		
	public ArrayList<T> getList(Screener<T> elementScreener) {
		//for each element in the list return the items that pass through the screener and should not come back false
		ArrayList<T> subSet = new ArrayList(); 
		
		for (T item: data) {
			if (elementScreener.test(item)) {
				subSet.add(item);
			}
	}
		return subSet;
} 

	@Override
	public String toString() {
		return "DataSetGeneric [\n size()=" + size() + "\n getMin()=" + getMin() + " getMax()=" + getMax()
				+ " Generic=\n" + data.toString() + "]";
	}

}
