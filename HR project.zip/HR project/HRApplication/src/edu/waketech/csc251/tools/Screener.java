package edu.waketech.csc251.tools;

public interface Screener<T> {
	boolean test(T objToTest);

}

