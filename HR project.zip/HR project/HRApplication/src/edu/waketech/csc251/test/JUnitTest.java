package edu.waketech.csc251.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.waketech.csc251.hr.person.Employee;
import edu.waketech.csc251.hr.person.EmployeeScreener;
import edu.waketech.csc251.tools.Screener;
import edu.waketech.csc251.hr.mgmt.Manager;
import edu.waketech.csc251.hr.mgmt.ManagerScreener;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import edu.waketech.csc251.collection.DataSetGeneric;
import edu.waketech.csc251.hr.mgmt.Executive;
import edu.waketech.csc251.hr.mgmt.ExecutiveScreen;


class JUnitTest {

	@Test
	void test() {
		
		Employee emp = new Employee("John", 1000);
		Manager mgr = new Manager("John", 1000, "Sales");
		Executive exec = new Executive("John", 1000, "Production");
		
		Screener<Employee> screenerEmp = new EmployeeScreener<Employee>();
		Screener<Employee> screenerMgr = new ManagerScreener<Employee>();
		Screener<Employee> screenerExec = new ExecutiveScreen<Employee>();
		
		DataSetGeneric<Employee> hrdbTest = new DataSetGeneric<>();
		
		hrdbTest.add(emp);
		hrdbTest.add(mgr);
		hrdbTest.add(exec);
		
		assertSame(hrdbTest, hrdbTest.getList());
		assertSame(emp, hrdbTest.getList(screenerEmp));
		assertSame(mgr, hrdbTest.getList(screenerMgr));
		assertSame(exec, hrdbTest.getList(screenerExec));


}
}
